/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laurajavagangsta;

import java.util.Random;

/**
 *
 * @author Laura
 */
class Gangsta {

  
   
    // gangster names
        String[] firstTitle = {"Ace of Spades","Blueman","The Boss", "Coon","Cottonmouth", "Dimebag", "Fat Tony", "Headlock", "Rattler", "Guttermouth", "Smuggie","The Cougar", "Queenie", "The Vicereine", "The Harlem Hatchett" };
        String[] secondTitle = {"Gams", "Wicked Witch", "Ruby", "Margarita", "Miss Demeanor", "Baby Blue", "Stiletto", "Bloody Death", "Whack-Whack", "Baldy Dom", "Shellackhead", "Bakha-Bakha", "Johnny Sausage", "Hsu Hai-ching", "The Prophet" };    
        
      
}
