/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laurajavagangsta;

import java.util.Scanner;
import java.util.*;

/**
 *
 * @author Laura
 */
public class LauraJavaGangsta {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
   
         public static void main(String[] args) throws InterruptedException 
        {
       Scanner kBoard = new Scanner(System.in);
        
       
        // title
         System.out.println("Welcome to Gangsta Game!!!");
         
        //ask how many names  
        System.out.print("Tell me how many names do you change: ");
       
         
        int number = kBoard.nextInt();
         
        //size an array of type String
        String userName[] = new String[number];
        kBoard.nextLine(); 
        
        //ask for names and store
        for( int i = 0; i < userName.length; i++)
        {
            System.out.println("\nEnter your full name " + (i+1) + ": ");
            userName[i]= kBoard.nextLine();
            
        }
        
        //printing out the steps for the users to know what we are doing in the back
        System.out.println("\n\nGet ready for your new street name");
        Thread.sleep(1000);
        System.out.println("........... Working on it,chill .............");
        Thread.sleep(1000);
        System.out.println("....... Lord Vader approves .......");
        Thread.sleep(2000);
        System.out.println("\nHe says it's fine\n\n");
        Thread.sleep(1000);
        
        for( int i = 0; i < number; i++)
         {
        
        // split name into first/last and initial
             // String First to transform to upper case and catch the second name
             //String Flower to catch the first name in lower case
             // String Last to chose a second name and set all to upper case
             
        String first = userName[i].substring(0, userName[i].indexOf(" ")).toUpperCase();
        String fLower = userName[i].substring(0, userName[i].indexOf(" ")).toLowerCase();
        String last = userName[i].substring(userName[i].indexOf(" ") + 1).toUpperCase().substring(0);

        
        //Printing out the new street names ;) i added the strings locally as well so they can be visible as well as in a class gangsta  
        System.out.println("You used to be: "+ userName[i] + "" );
           String[] firstTitle = {"Ace of Spades","Blueman","The Boss", "Coon","Cottonmouth", "Dimebag", "Fat Tony", "Headlock", "Rattler", "Guttermouth", "Smuggie","The Cougar", "Queenie", "The Vicereine", "The Harlem Hatchett" };
           String[] secondTitle = {"Gams", "Wicked Witch", "Ruby", "Margarita", "Miss Demeanor", "Baby Blue", "Stiletto", "Bloody Death", "Whack-Whack", "Baldy Dom", "Shellackhead", "Bakha-Bakha", "Johnny Sausage", "Hsu Hai-ching", "The Prophet" };
        System.out.println("Your gangsta name is: "+ first.substring(0, 1) + ". "
                + " " + (firstTitle[new Random().nextInt(firstTitle.length)]) + " " + last + " " + fLower + " " 
                + (secondTitle[new Random().nextInt(secondTitle.length)]) + "\n");
       
    }
        }
}
             